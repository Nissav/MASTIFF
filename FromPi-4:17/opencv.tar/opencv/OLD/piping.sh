#!/bin/bash



echo "This is output $1"
