#!/bin/bash
#perform image detection

out=$(./main2 camera setup)

echo "Output is $out" 


