#include "i2c.h"

int main()
{
	return 0;
}
